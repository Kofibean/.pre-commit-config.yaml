import { GeneratorConfig } from './types';

export const INITIAL_CONFIG: GeneratorConfig = {
  notebookPath: 'analysis.ipynb',
  libraries: {
    numpy: true,
    pandas: true,
    torch: false,
    random: true,
  },
  outputDir: './artifacts',
  parameters: [
    {
      id: '1',
      name: 'input_path',
      type: 'string',
      defaultValue: 'data/raw.csv',
      description: 'Path to the input dataset'
    },
    {
      id: '2',
      name: 'seed',
      type: 'int',
      defaultValue: '42',
      description: 'Master random seed'
    }
  ],
};

export const generateSystemPrompt = (): string => {
  return `You are an expert Senior Python Engineer specializing in Reproducible Science and MLOps. 
  Your goal is to write robust, production-grade CLI tools. 
  Focus on determinism, type-safety, and clear logging.`;
};

export const generateUserPrompt = (config: GeneratorConfig): string => {
  const libChecks = [];
  if (config.libraries.random) libChecks.push('Python random module');
  if (config.libraries.numpy) libChecks.push('NumPy');
  if (config.libraries.pandas) libChecks.push('Pandas');
  if (config.libraries.torch) libChecks.push('PyTorch (CPU/CUDA determinism)');

  const paramsList = config.parameters.map(p => 
    `- \`${p.name}\` (${p.type}): Default "${p.defaultValue}". Help: "${p.description}"`
  ).join('\n');

  return `
  Create a Python CLI script named \`reproduce_analysis.py\` for the notebook located at \`${config.notebookPath}\`.
  
  **Requirements:**
  1. **CLI Framework:** Use \`click\` or \`argparse\` to expose the following parameters as CLI arguments:
     ${paramsList}
     - Add a global flag \`--verify\` to run in verification mode.
     - Add a global flag \`--output-dir\` defaulting to \`${config.outputDir}\`.

  2. **Determinism & Environment (CRITICAL):**
     - Before importing numerical libraries, set environment variables to force single-threaded execution for BLAS/MKL/OpenMP to ensure deterministic results (e.g., OMP_NUM_THREADS=1, MKL_NUM_THREADS=1, etc.).
     - Explicitly seed the Random Number Generators (RNGs) for: ${libChecks.join(', ')}.
     - If PyTorch is selected, ensure \`torch.use_deterministic_algorithms(True)\` is set if available.

  3. **Execution:**
     - Use \`papermill\` to execute the notebook.
     - Pass the CLI parameters to the notebook.
     - Save the output notebook to the output directory.
     - Convert the output notebook to an HTML report (using nbconvert API or command) and save it to the output directory.

  4. **Manifest & Artifacts:**
     - After execution, generate a \`manifest.json\` in the output directory containing:
       - The run parameters used.
       - A \`pip freeze\` snapshot of the environment.
       - SHA256 checksums of all generated artifacts (the output notebook, the HTML report, and any CSVs found in the output folder).

  5. **Verify Mode:**
     - If \`--verify\` is passed, the tool should:
       - Run the analysis in a temporary directory.
       - Calculate checksums of the new artifacts.
       - Compare them bit-for-bit against the existing artifacts in the specified output directory.
       - Print a success/failure report.

  **Output Format:**
  - Return ONLY the raw Python code. Do not wrap in markdown code blocks.
  - Include comments explaining the deterministic enforcement.
  - Assume the script is run in an environment where \`papermill\`, \`jupyter\`, \`nbconvert\` are installed.
  `;
};
