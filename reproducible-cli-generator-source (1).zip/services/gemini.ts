import { GoogleGenAI } from "@google/genai";
import { GeneratorConfig } from "../types";
import { generateSystemPrompt, generateUserPrompt } from "../constants";

const getApiKey = (): string => {
  const key = process.env.API_KEY;
  if (!key) {
    console.warn("API_KEY not found in environment variables");
    return "";
  }
  return key;
};

export const generateCliScript = async (config: GeneratorConfig): Promise<string> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("Missing API Key. Please ensure process.env.API_KEY is set.");
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    // We use gemini-2.5-flash for speed and code capability
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: generateSystemPrompt(),
        temperature: 0.2, // Low temperature for deterministic code generation
      },
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: generateUserPrompt(config)
            }
          ]
        }
      ]
    });

    const text = response.text;
    if (!text) throw new Error("No content generated");
    
    // Strip markdown code blocks if present (though we asked not to, sometimes models ignore)
    const cleanText = text.replace(/^```python\n/, '').replace(/^```\n/, '').replace(/```$/, '');
    
    return cleanText;

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};
