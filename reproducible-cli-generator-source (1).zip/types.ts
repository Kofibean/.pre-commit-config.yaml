export interface Parameter {
  id: string;
  name: string;
  type: 'string' | 'int' | 'float' | 'bool';
  defaultValue: string;
  description: string;
}

export interface GeneratorConfig {
  notebookPath: string;
  libraries: {
    numpy: boolean;
    pandas: boolean;
    torch: boolean;
    random: boolean;
  };
  outputDir: string;
  parameters: Parameter[];
}

export type CodeGenerationStatus = 'idle' | 'generating' | 'success' | 'error';
