import React, { useState } from 'react';
import { 
  FileCode2, 
  FlaskConical, 
  RefreshCw, 
  Cpu, 
  Fingerprint, 
  ShieldCheck,
  Play,
  Archive,
  Info
} from 'lucide-react';
import JSZip from 'jszip';
import ParamBuilder from './components/ParamBuilder';
import LibraryToggle from './components/LibraryToggle';
import CodeViewer from './components/CodeViewer';
import { GeneratorConfig } from './types';
import { INITIAL_CONFIG } from './constants';
import { generateCliScript } from './services/gemini';

const App: React.FC = () => {
  const [config, setConfig] = useState<GeneratorConfig>(INITIAL_CONFIG);
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [status, setStatus] = useState<'idle' | 'generating' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  const handleGenerate = async () => {
    setStatus('generating');
    setErrorMsg(null);
    try {
      const code = await generateCliScript(config);
      setGeneratedCode(code);
      setStatus('success');
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message || 'Failed to generate code.');
    }
  };

  const handleExportSource = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      
      const filePaths = [
        'metadata.json',
        'index.html',
        'index.tsx',
        'App.tsx',
        'types.ts',
        'constants.ts',
        'services/gemini.ts',
        'components/LibraryToggle.tsx',
        'components/ParamBuilder.tsx',
        'components/CodeViewer.tsx'
      ];

      for (const path of filePaths) {
        try {
          const response = await fetch(path);
          if (response.ok) {
            const content = await response.text();
            zip.file(path, content);
          }
        } catch (e) {
          console.warn(`Could not include ${path} in zip`, e);
        }
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'reproducible-cli-generator-source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Export failed", err);
      alert("Failed to bundle source code. Check console for details.");
    } finally {
      setIsExporting(false);
    }
  };

  const updateConfig = (key: keyof GeneratorConfig, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const toggleLibrary = (lib: keyof typeof config.libraries, checked: boolean) => {
    setConfig(prev => ({
      ...prev,
      libraries: { ...prev.libraries, [lib]: checked }
    }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-science-500/30 selection:text-science-100">
      
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-science-500 to-science-700 p-2 rounded-lg shadow-lg shadow-science-500/20">
              <FlaskConical className="text-white h-5 w-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white tracking-tight">Reproducible CLI Gen</h1>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Scientific Workflow Automation</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="group relative">
              <button 
                onClick={handleExportSource}
                disabled={isExporting}
                className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-science-600 hover:bg-science-500 rounded-lg transition-all shadow-lg shadow-science-500/20"
              >
                {isExporting ? <RefreshCw className="animate-spin" size={14} /> : <Archive size={14} />}
                Export Project (.zip)
              </button>
              <div className="absolute top-full right-0 mt-2 w-48 bg-slate-800 border border-slate-700 p-2 rounded shadow-xl text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                Click here to download the entire source code of this tool as a ZIP folder.
              </div>
            </div>

            <div className="h-6 w-[1px] bg-slate-800 mx-1"></div>
            
            <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
               <div className="flex items-center gap-2" title="Single-threaded BLAS/MKL enforcement">
                  <Cpu size={14} className="text-science-500"/> Deterministic Env
               </div>
               <div className="flex items-center gap-2" title="Bitwise artifact verification">
                  <ShieldCheck size={14} className="text-science-500"/> SHA256 Verify
               </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[calc(100vh-8rem)]">
          
          {/* Configuration Panel */}
          <div className="lg:col-span-5 flex flex-col gap-6 overflow-y-auto pr-2 pb-10">
            
            <div className="bg-science-900/20 border border-science-500/20 rounded-lg p-3 flex items-start gap-3">
               <Info className="text-science-400 shrink-0 mt-0.5" size={16} />
               <p className="text-xs text-slate-400 leading-relaxed">
                 Configure your reproducible environment below. Use the <strong>Export Project (.zip)</strong> button in the header to save the source files for this entire generator.
               </p>
            </div>

            {/* Section: Project Basics */}
            <section className="space-y-4">
               <h2 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                <FileCode2 size={16} className="text-science-400" />
                Target Settings
              </h2>
              <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1.5 uppercase">Notebook Path</label>
                  <input 
                    type="text" 
                    value={config.notebookPath}
                    onChange={(e) => updateConfig('notebookPath', e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-science-500 focus:border-science-500 outline-none transition-all"
                    placeholder="path/to/analysis.ipynb"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1.5 uppercase">Output Artifacts Dir</label>
                  <input 
                    type="text" 
                    value={config.outputDir}
                    onChange={(e) => updateConfig('outputDir', e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-science-500 focus:border-science-500 outline-none transition-all"
                    placeholder="./output"
                  />
                </div>
              </div>
            </section>

            {/* Section: Determinism Config */}
            <section className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                <Fingerprint size={16} className="text-science-400" />
                Reproducibility Scope
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <LibraryToggle 
                  label="Random" 
                  description="Seed Python's random"
                  checked={config.libraries.random} 
                  onChange={(v) => toggleLibrary('random', v)}
                />
                <LibraryToggle 
                  label="NumPy" 
                  description="Seed np.random"
                  checked={config.libraries.numpy} 
                  onChange={(v) => toggleLibrary('numpy', v)}
                />
                <LibraryToggle 
                  label="Pandas" 
                  description="Consistent I/O & sort"
                  checked={config.libraries.pandas} 
                  onChange={(v) => toggleLibrary('pandas', v)}
                />
                <LibraryToggle 
                  label="PyTorch" 
                  description="Deterministic algos"
                  checked={config.libraries.torch} 
                  onChange={(v) => toggleLibrary('torch', v)}
                />
              </div>
            </section>

            {/* Section: Parameters */}
            <section className="flex-1">
              <ParamBuilder 
                parameters={config.parameters} 
                onChange={(p) => updateConfig('parameters', p)} 
              />
            </section>

            <button
              onClick={handleGenerate}
              disabled={status === 'generating'}
              className={`
                w-full py-4 rounded-xl font-bold text-sm tracking-wide shadow-lg transition-all
                flex items-center justify-center gap-2
                ${status === 'generating' 
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                  : 'bg-gradient-to-r from-science-600 to-science-500 hover:from-science-500 hover:to-science-400 text-white shadow-science-500/25 hover:shadow-science-500/40 transform hover:-translate-y-0.5'}
              `}
            >
              {status === 'generating' ? (
                <>
                  <RefreshCw className="animate-spin" size={18} />
                  Generating Script...
                </>
              ) : (
                <>
                  <Play size={18} fill="currentColor" />
                  Generate Reproducible CLI
                </>
              )}
            </button>
            {errorMsg && (
              <div className="p-3 bg-red-900/20 border border-red-800 rounded-lg text-red-200 text-xs">
                {errorMsg}
              </div>
            )}
          </div>

          {/* Preview Panel */}
          <div className="lg:col-span-7 h-full flex flex-col">
            <div className="flex-1 h-full min-h-[500px]">
              <CodeViewer 
                code={generatedCode} 
                isLoading={status === 'generating'} 
                config={config} 
              />
            </div>
            
            <div className="mt-4 p-4 bg-slate-900/50 border border-slate-800 rounded-lg">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">How Verify Mode Works</h3>
              <div className="flex items-center justify-between text-xs text-slate-500 font-mono">
                 <div className="flex flex-col items-center gap-1">
                    <span className="p-1.5 bg-slate-800 rounded text-science-400">params.json</span>
                    <span>1. Load</span>
                 </div>
                 <div className="h-[1px] bg-slate-700 w-8"></div>
                 <div className="flex flex-col items-center gap-1">
                    <span className="p-1.5 bg-slate-800 rounded text-yellow-400">Temp Dir</span>
                    <span>2. Re-run</span>
                 </div>
                 <div className="h-[1px] bg-slate-700 w-8"></div>
                 <div className="flex flex-col items-center gap-1">
                    <span className="p-1.5 bg-slate-800 rounded text-pink-400">SHA256</span>
                    <span>3. Hash</span>
                 </div>
                 <div className="h-[1px] bg-slate-700 w-8"></div>
                 <div className="flex flex-col items-center gap-1">
                    <span className="p-1.5 bg-slate-800 rounded text-green-400">Compare</span>
                    <span>4. Assert</span>
                 </div>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default App;