import React from 'react';
import { Copy, Download, Terminal, CheckCircle2, Archive } from 'lucide-react';
import JSZip from 'jszip';
import { GeneratorConfig } from '../types';

interface CodeViewerProps {
  code: string;
  isLoading: boolean;
  config: GeneratorConfig;
}

const CodeViewer: React.FC<CodeViewerProps> = ({ code, isLoading, config }) => {
  const [copied, setCopied] = React.useState(false);
  const [zipping, setZipping] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'reproduce_analysis.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    setZipping(true);
    try {
      const zip = new JSZip();
      
      // 1. The Script
      zip.file('reproduce_analysis.py', code);
      
      // 2. Requirements.txt
      const reqs = [
        'papermill',
        'jupyter',
        'nbconvert',
        'click',
      ];
      if (config.libraries.numpy) reqs.push('numpy');
      if (config.libraries.pandas) reqs.push('pandas');
      if (config.libraries.torch) reqs.push('torch');
      zip.file('requirements.txt', reqs.join('\n'));

      // 3. README.md
      const readme = `# Reproducible Analysis CLI

This project contains a deterministic wrapper for \`${config.notebookPath}\`.

## Setup
\`\`\`bash
pip install -r requirements.txt
\`\`\`

## Usage
Run the analysis:
\`\`\`bash
python reproduce_analysis.py --output-dir ${config.outputDir}
\`\`\`

Verify existing results:
\`\`\`bash
python reproduce_analysis.py --verify --output-dir ${config.outputDir}
\`\`\`

## Features
- Forced single-threaded BLAS for determinism.
- seeded RNGs for ${Object.entries(config.libraries).filter(([_, v]) => v).map(([k]) => k).join(', ')}.
- SHA256 manifest generation.
- Bitwise verification mode.
`;
      zip.file('README.md', readme);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'reproducible_project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip', err);
    } finally {
      setZipping(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4 min-h-[400px]">
        <div className="w-12 h-12 border-4 border-science-500/30 border-t-science-500 rounded-full animate-spin"></div>
        <p className="animate-pulse font-mono text-sm">Generating deterministic CLI wrapper...</p>
      </div>
    );
  }

  if (!code) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-4 min-h-[400px]">
        <Terminal size={48} className="opacity-20" />
        <p className="max-w-xs text-center text-sm">
          Configure your notebook settings on the left and click "Generate CLI" to create your reproducible script.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#0d1117] rounded-lg border border-slate-800 overflow-hidden shadow-2xl">
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800/50 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Terminal size={16} className="text-science-400" />
          <span className="text-sm font-medium text-slate-300 font-mono">reproduce_analysis.py</span>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-700/50 hover:bg-slate-700 rounded-md transition-colors"
          >
            {copied ? <CheckCircle2 size={14} className="text-green-400" /> : <Copy size={14} />}
            {copied ? 'Copy' : 'Copy'}
          </button>
          <button 
            onClick={handleDownloadZip}
            disabled={zipping}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-700 hover:bg-slate-600 rounded-md transition-colors"
          >
            {zipping ? <RefreshCw size={14} className="animate-spin" /> : <Archive size={14} />}
            Bundle (.zip)
          </button>
          <button 
            onClick={handleDownloadFile}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-science-600 hover:bg-science-500 rounded-md transition-colors"
          >
            <Download size={14} />
            Script (.py)
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto p-4 relative group">
        <pre className="font-mono text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">
          {code}
        </pre>
      </div>
    </div>
  );
};

// Re-importing RefreshCw since it's used in the zipping state
import { RefreshCw } from 'lucide-react';

export default CodeViewer;