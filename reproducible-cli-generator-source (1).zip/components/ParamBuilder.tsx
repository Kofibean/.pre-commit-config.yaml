import React from 'react';
import { Parameter } from '../types';
import { Plus, Trash2, Settings2 } from 'lucide-react';

interface ParamBuilderProps {
  parameters: Parameter[];
  onChange: (params: Parameter[]) => void;
}

const ParamBuilder: React.FC<ParamBuilderProps> = ({ parameters, onChange }) => {
  
  const addParam = () => {
    const newId = Math.random().toString(36).substr(2, 9);
    onChange([
      ...parameters, 
      { id: newId, name: 'new_param', type: 'string', defaultValue: '', description: 'Description' }
    ]);
  };

  const updateParam = (id: string, field: keyof Parameter, value: string) => {
    onChange(parameters.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const removeParam = (id: string) => {
    onChange(parameters.filter(p => p.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2">
        <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
          <Settings2 size={16} className="text-science-400" />
          Notebook Parameters
        </label>
        <button 
          onClick={addParam}
          className="text-xs flex items-center gap-1 bg-science-900/50 hover:bg-science-900 text-science-200 px-2 py-1 rounded border border-science-800 transition-colors"
        >
          <Plus size={12} /> Add Parameter
        </button>
      </div>

      <div className="space-y-3">
        {parameters.map((param) => (
          <div key={param.id} className="grid grid-cols-12 gap-2 bg-slate-800/50 p-3 rounded-md border border-slate-700/50 group hover:border-slate-600 transition-colors">
            <div className="col-span-3">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Name</label>
              <input 
                type="text" 
                value={param.name}
                onChange={(e) => updateParam(param.id, 'name', e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:border-science-500 focus:outline-none font-mono"
                placeholder="param_name"
              />
            </div>
            <div className="col-span-2">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Type</label>
              <select 
                value={param.type}
                onChange={(e) => updateParam(param.id, 'type', e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:border-science-500 focus:outline-none"
              >
                <option value="string">String</option>
                <option value="int">Integer</option>
                <option value="float">Float</option>
                <option value="bool">Boolean</option>
              </select>
            </div>
            <div className="col-span-3">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Default</label>
              <input 
                type="text" 
                value={param.defaultValue}
                onChange={(e) => updateParam(param.id, 'defaultValue', e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:border-science-500 focus:outline-none font-mono"
                placeholder="value"
              />
            </div>
            <div className="col-span-3">
              <label className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Description</label>
              <input 
                type="text" 
                value={param.description}
                onChange={(e) => updateParam(param.id, 'description', e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:border-science-500 focus:outline-none"
                placeholder="Help text"
              />
            </div>
            <div className="col-span-1 flex items-end justify-center pb-1">
               <button 
                onClick={() => removeParam(param.id)}
                className="text-slate-500 hover:text-red-400 transition-colors"
                title="Remove Parameter"
               >
                 <Trash2 size={14} />
               </button>
            </div>
          </div>
        ))}
        
        {parameters.length === 0 && (
          <div className="text-center py-8 border-2 border-dashed border-slate-800 rounded-lg text-slate-500 text-sm">
            No parameters defined. The notebook will run without arguments.
          </div>
        )}
      </div>
    </div>
  );
};

export default ParamBuilder;
