import React from 'react';
import { Check } from 'lucide-react';

interface LibraryToggleProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  description: string;
}

const LibraryToggle: React.FC<LibraryToggleProps> = ({ label, checked, onChange, description }) => {
  return (
    <div 
      onClick={() => onChange(!checked)}
      className={`
        cursor-pointer border rounded-lg p-4 transition-all duration-200
        flex items-start gap-3 select-none
        ${checked 
          ? 'bg-science-950/40 border-science-500/50 shadow-[0_0_15px_rgba(20,184,166,0.1)]' 
          : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'}
      `}
    >
      <div className={`
        mt-1 w-5 h-5 rounded border flex items-center justify-center transition-colors
        ${checked ? 'bg-science-600 border-science-500' : 'bg-slate-800 border-slate-600'}
      `}>
        {checked && <Check size={14} className="text-white" />}
      </div>
      <div>
        <h4 className={`font-medium ${checked ? 'text-science-200' : 'text-slate-300'}`}>
          {label}
        </h4>
        <p className="text-xs text-slate-400 mt-1">{description}</p>
      </div>
    </div>
  );
};

export default LibraryToggle;